﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibararySystemDemo.model.dataindex
{
	public class BookClassIndexView
	{

		public int ClassID { get; set; }

		public string Class { get; set; }

	}
}
